# personal project: predictive model about the Anthropometric Survey of US Army Personnel (ANSUR 1)

this project is an predictive modelling's trial about correlations between 
some physical features and anthropometric survey. He aims to forecast the evolution of weight according to some correlated features. 
The first version of this study has been published in 1988. He includes 140 measures of 4000 test subjects. this link will 
conduct the website's experience: https://www.openlab.psu.edu/ansur/


 The IDE "Microsoft Visual studio" and the software "Python3.8" have been used for this test. 


  A socio-demographic map has made to sum up the distribution of average features about test's subjects,
according their birthplace. You can open the file "sociodemographic_map.html" with one Web browser ( Chrome....).
The website "https://www.kaggle.com/paultimothymooney/latitude-and-longitude-for-every-country-and-state?select=
world_country_and_usa_states_latitude_and_longitude_values.csv" has been used to extract data GPS and to make the map.   	

   The full protocol of analysis is explained in the file "modeling_and_predictive_ANSUR1.docx".

    

